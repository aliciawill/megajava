package �׷���;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class ���� {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(300, 950);
		
		JLabel img = new JLabel();
		f.add(img);
		
		ImageIcon icon = new ImageIcon("cal.jpg");
		img.setIcon(icon);
		
		JLabel n1 = new JLabel("����1");
		JLabel n2 = new JLabel("����2");
		
		JTextField t1 = new JTextField(5);
		JTextField t2 = new JTextField(5);
		
		JButton plus = new JButton("+");
		
		FlowLayout flow = new FlowLayout();
		f.setLayout(flow);
		
		Font font = new Font("���� ����", Font.BOLD, 50);
		n1.setFont(font);
		n2.setFont(font);
		t1.setFont(font);
		t2.setFont(font);
		plus.setFont(font);
		
		f.add(n1);
		f.add(t1);
		f.add(n2);
		f.add(t2);
		f.add(plus);	
		
		t1.setBackground(Color.yellow);
		t2.setBackground(Color.yellow);
		plus.setBackground(Color.BLUE);
		t1.setForeground(Color.RED);
		t2.setForeground(Color.RED);
		plus.setForeground(Color.RED);
		
		plus.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//���� �Է��� �� ���� ������ �;���.
				String num1 = t1.getText();
				String num2 = t2.getText();
				
				int num11 = Integer.parseInt(num1);
				int num22 = Integer.parseInt(num2);
				
				//���ؼ� ����غ��ô�.
				System.out.println(num11 + num22);
				
			}
		});
		
		
		
		
		f.setVisible(true);
	}

}
