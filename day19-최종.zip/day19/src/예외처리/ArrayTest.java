package ����ó��;

public class ArrayTest {

	public static void main(String[] args) {
		int[] arr = {1, 2}; //0~1
		System.out.println(arr[2]);
	}

}
