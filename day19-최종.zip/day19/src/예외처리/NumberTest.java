package ����ó��;

public class NumberTest {

	public static void main(String[] args) {
		String n1 = "100��";
		int n2 = Integer.parseInt(n1);
		System.out.println(n2 + 1);
	}

}
