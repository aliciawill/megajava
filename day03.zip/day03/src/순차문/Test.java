package ������;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		JFrame	f = new JFrame();
		f.setSize(500, 500);
		JButton b = new JButton("���� ������.");
		f.add(b);
		b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(f, "�ȳ�");
			}
		});
		f.setVisible(true);
	}

}
