package 예외처리;

public interface Car {
	//추상(=불완전)메소드만 가질 수 있음.
	public abstract void run();
	
}
