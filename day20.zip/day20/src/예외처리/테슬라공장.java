package 예외처리;

public class 테슬라공장 {

	public static void main(String[] args) {
		테슬라 t = new 테슬라();
		t.run();
	}

}
