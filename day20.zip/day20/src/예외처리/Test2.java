package 예외처리;

import java.util.ArrayList;
import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("문장 입력>> ");
		String data = sc.next();
		String[] dataList= data.split("");
		ArrayList<String> list = new ArrayList<String>();
		
	}
}
