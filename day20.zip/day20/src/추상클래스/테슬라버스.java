package 추상클래스;

public class 테슬라버스 extends 테슬라 {

	@Override
	public void 싣다() {
		System.out.println("승객을 싣다.");
	}

}
