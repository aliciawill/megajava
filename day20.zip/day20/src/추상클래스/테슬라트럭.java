package 추상클래스;

public class 테슬라트럭 extends 테슬라 {

	@Override
	public void 싣다() {
		System.out.println("물건을 싣다.");
	}

}
