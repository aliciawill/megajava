package ��������;

public class �Խ��� {
	int no;
	String title;
	String content;
	String writer;
	
	public �Խ���(int no, String title, String content, String writer) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
	}

	@Override
	public String toString() {
		return "�Խ��� [no=" + no + ", title=" + title + ", content=" + content + ", writer=" + writer + "]";
	}
}
